package it.uniroma2.dicii.bd;

import it.uniroma2.dicii.bd.controller.ApplicationController;

public class Main {

    public static void main(String[] args){
        ApplicationController applicationController = new ApplicationController();
        applicationController.start();
    }

}
