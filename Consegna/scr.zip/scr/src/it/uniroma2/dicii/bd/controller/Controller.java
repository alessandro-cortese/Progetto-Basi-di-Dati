package it.uniroma2.dicii.bd.controller;

public interface Controller {

    void start();

}
